# Sampatus logo asset

The supplied Sampatus logo is stored here:

public/images/sampatus-logo.png

In a Next.js website, reference it with:

<Image
  src="/images/sampatus-logo.png"
  alt="Sampatus logo"
  width={320}
  height={420}
  priority
/>

You can replace sampatus-logo.png with an updated logo later, keeping the same filename.
The deployed Vercel website will not change until this file is added to the website project
and the updated project is deployed.
